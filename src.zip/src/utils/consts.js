export const MAIN_ROUTE = '/'
export const WOMEN_ROUTE = '/women'
export const MEN_ROUTE = '/men'
export const ERROR_ROUTE = '*'