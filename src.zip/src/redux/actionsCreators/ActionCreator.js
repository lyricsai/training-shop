export const GET_WOMEN = 'GET_WOMEN'
export const GET_MEN = 'GET_MEN'
export const GET_BANNERS = 'GET_BANNERS'
export const GET_COLLECTIONS = 'GET_COLLECTIONS'
export const GET_FILTERED = 'GET_FILTERED'
export const GET_PREVIEW = 'GET_PREVIEW'
export const GET_REVIEW = 'GET_REVIEW'

